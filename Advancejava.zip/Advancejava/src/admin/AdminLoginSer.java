package admin;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Datahelper;

/**
 * Servlet implementation class AdminLoginSer
 */
@WebServlet("/AdminLoginSer")
public class AdminLoginSer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		try {
			Datahelper.connection();
			ResultSet res=Datahelper.dqlOPe("select * from admin where username='"+request.getParameter("txtuser")+"' and password='"+request.getParameter("txtpass")+"'");
			if(res.next())
			{
				HttpSession session = request.getSession();
				session.setAttribute("uid",request.getParameter("txtuser"));
				response.sendRedirect("databaseui/databaseinsertion.jsp");
				
			}
			else
			{
				response.sendRedirect("index.jsp?error=invalid userid and password");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
